(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3112], {
        6629: function(i, e, o) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/[id]", function() {
                return o(9993)
            }])
        },
        4022: function(i, e, o) {
            "use strict";
            var l = o(5893),
                n = o(5675),
                t = o.n(n);
            o(7294);
            var s = o(9473);
            e.Z = function() {
                var i, e, o, n, a, d, c, r, u, v, p, h, g, m, x;
                let {
                    Productdata: j
                } = (0, s.v9)(i => i.product);
                return (0, l.jsxs)("div", {
                    className: "main_product_box",
                    children: [(0, l.jsx)("div", {
                        className: "boxes_image",
                        children: (0, l.jsx)(t(), {
                            className: "boxes_img",
                            src: "/images/corevalues_bg.png",
                            layout: "fill",
                            objectFit: "cover",
                            objectPosition: "center"
                        })
                    }), (0, l.jsxs)("div", {
                        className: "boxes_head_para",
                        children: [(0, l.jsx)("h3", {
                            className: "boxes_head1",
                            children: j && (null == j ? void 0 : null === (i = j[0]) || void 0 === i ? void 0 : i.heading)
                        }), j && (null == j ? void 0 : null === (e = j[0]) || void 0 === e ? void 0 : null === (o = e.data) || void 0 === o ? void 0 : o.map((i, e) => (0, l.jsx)("p", {
                            className: "mailer_para1",
                            children: i.description
                        }, e))), (0, l.jsx)("h3", {
                            className: "boxes_head2",
                            children: j && (null == j ? void 0 : null === (n = j[0]) || void 0 === n ? void 0 : n.headings)
                        }), j && (null == j ? void 0 : null === (a = j[0]) || void 0 === a ? void 0 : null === (d = a.data1) || void 0 === d ? void 0 : d.map((i, e) => (0, l.jsx)("p", {
                            className: "boxes_para2",
                            children: i.descriptions
                        }, e)))]
                    }), j && (null == j ? void 0 : null === (c = j[0]) || void 0 === c ? void 0 : null === (r = c.detail_image) || void 0 === r ? void 0 : r.map((i, e) => (0, l.jsx)("div", {
                        className: "main_boxbiotek",
                        children: (0, l.jsx)(t(), {
                            className: "boxbiotek",
                            src: i,
                            layout: "fill",
                            objectFit: "cover",
                            objectPosition: "center"
                        })
                    }, e))), (0, l.jsxs)("div", {
                        className: "main_specs_boxes",
                        children: [(0, l.jsx)("h3", {
                            children: j && (null == j ? void 0 : null === (u = j[0]) || void 0 === u ? void 0 : u.heading1)
                        }), (0, l.jsx)("p", {
                            children: j && (null === (v = null == j ? void 0 : null === (p = j[0]) || void 0 === p ? void 0 : p.data_des[0]) || void 0 === v ? void 0 : v.description1)
                        }), j && (null == j ? void 0 : null === (h = j[0]) || void 0 === h ? void 0 : null === (g = h.data2) || void 0 === g ? void 0 : g.map((i, e) => (0, l.jsxs)("div", {
                            style: {
                                display: "flex",
                                justifyContent: "center"
                            },
                            children: [(0, l.jsx)("p", {
                                children: i.names
                            }), (0, l.jsx)("p", {
                                children: i.details
                            })]
                        }, e))), (0, l.jsx)("p", {
                            children: j && (null === (m = null == j ? void 0 : null === (x = j[0]) || void 0 === x ? void 0 : x.data_des[1]) || void 0 === m ? void 0 : m.description1)
                        })]
                    })]
                })
            }
        },
        8975: function(i, e, o) {
            "use strict";
            var l = o(5893),
                n = o(5675),
                t = o.n(n);
            o(7294), e.Z = function() {
                return (0, l.jsxs)("div", {
                    className: "main_shipping_box",
                    children: [(0, l.jsx)("div", {
                        className: "shipping_image",
                        children: (0, l.jsx)(t(), {
                            className: "shipping_img",
                            src: "/images/corevalues_bg.png",
                            layout: "fill",
                            objectFit: "cover",
                            objectPosition: "center"
                        })
                    }), (0, l.jsxs)("div", {
                        className: "shipping_head_para",
                        children: [(0, l.jsx)("h3", {
                            className: "shipping_head",
                            children: "Send out your best shipping boxes"
                        }), (0, l.jsx)("p", {
                            className: "shipping_para1",
                            children: "When you use custom packaging boxes for your products, you get both a cost-saving packaging solution and an extra opportunity to get your brand noticed. Our heavy-duty shipping boxes are designed to help keep your products safe and looking great – in transit and storage."
                        }), (0, l.jsx)("p", {
                            className: "shipping_para2",
                            children: "Store your biggest packages and heaviest loads in our durable custom shipping boxes. These mailing boxes are made of sturdy and sustainable corrugated cardboard that protects your customer orders. Every shipping box arrives well as new and keeps all the delivered items intact."
                        }), (0, l.jsx)("h3", {
                            className: "shipping_head2",
                            children: "Shipped to You Right on Time"
                        }), (0, l.jsx)("p", {
                            className: "shipping_para3",
                            children: "Our custom shipping boxes take only 10 - 15 business days to produce. This gives us enough time to check your artwork, correct any technical issues, print, cut, glue, and pack your shipping boxes before we ship them. Your shipping boxes will be delivered to your door within a few days after we ship them."
                        })]
                    }), (0, l.jsx)("div", {
                        className: "main_foldandflap",
                        children: (0, l.jsx)(t(), {
                            className: "fold_flap",
                            src: "/images/foldandflap.png",
                            layout: "fill",
                            objectFit: "cover",
                            objectPosition: "center"
                        })
                    }), (0, l.jsxs)("div", {
                        className: "main_specs_shipping",
                        children: [(0, l.jsx)("h3", {
                            children: "Custom Shipping Box Specs"
                        }), (0, l.jsx)("p", {
                            children: "Your order will be produced to the exact size you need within the following ranges:"
                        }), (0, l.jsx)("p", {
                            children: "Length: 2 – 30 in"
                        }), (0, l.jsx)("p", {
                            children: "Width: 2 – 29 in"
                        }), (0, l.jsx)("p", {
                            children: "Depth: 2.5 – 32 in"
                        }), (0, l.jsx)("p", {
                            children: " The customizable measurements refer to the interior dimensions of the box. You may want to add space on either side of you"
                        })]
                    })]
                })
            }
        },
        614: function(i, e, o) {
            "use strict";
            o.r(e);
            var l = o(5893);
            o(7294);
            var n = o(1163);
            o(5675);
            var t = o(682);
            let s = () => {
                let i = (0, n.useRouter)();
                return console.log(i, "notfound"), (0, l.jsx)(t.Z, {
                    children: (0, l.jsxs)("div", {
                        children: [(0, l.jsx)("div", {
                            style: {
                                marginTop: "40px"
                            },
                            children: (0, l.jsx)("img", {
                                className: "notfoundimage",
                                src: "/images/notfound.png"
                            })
                        }), (0, l.jsx)("h1", {
                            style: {
                                fontWeight: "semibold",
                                textAlign: "center",
                                marginTop: "50px"
                            },
                            children: "404 - Page Not Found"
                        }), (0, l.jsxs)("p", {
                            style: {
                                textAlign: "center",
                                marginTop: "20px"
                            },
                            children: ["Oops! The page ", "you're", " looking for does not exist."]
                        })]
                    })
                })
            };
            e.default = s
        },
        9993: function(i, e, o) {
            "use strict";
            o.r(e), o.d(e, {
                __N_SSP: function() {
                    return g
                }
            });
            var l = o(5893),
                n = o(7356);
            o(4022);
            var t = o(6037),
                s = o(4046),
                a = o(1628);
            o(8975), o(5955);
            var d = o(9590),
                c = o(9008),
                r = o.n(c);
            o(1163);
            var u = o(7294),
                v = o(9473),
                p = o(614);
            let h = i => {
                var e, o, c, h, g, m, x, j, _, b, f, y, w, k, N, P, C, F, T, W, B, S, Z, E, D, O, z, L, Y, q, A, G, R, X, U, H, I, J, K, M;
                let {
                    maetaData: Q
                } = i, {
                    Productdata: V
                } = (0, v.v9)(i => i.product);
                (0, u.useEffect)(() => {
                    window.scroll({
                        top: 0,
                        behavior: "instant"
                    })
                }, []);
                let $ = (null == V ? void 0 : V.length) === 0;
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsxs)(r(), {
                        children: [(0, l.jsx)("meta", {
                            name: "viewport",
                            content: "width=device-width, initial-scale=1"
                        }), (0, l.jsx)("meta", {
                            property: "og:locale",
                            content: "en_US"
                        }), (0, l.jsx)("meta", {
                            property: "og:type",
                            content: "website"
                        }), (0, l.jsx)("meta", {
                            property: "og:site_name",
                            content: "Biotech Packages"
                        }), (0, l.jsx)("meta", {
                            property: "og:url",
                            content: "https://www.biotechpackages.com/".concat(null == V ? void 0 : null === (e = V[0]) || void 0 === e ? void 0 : e.slug)
                        }), (0, l.jsx)("link", {
                            rel: "canonical",
                            href: "https://www.biotechpackages.com/".concat(null == V ? void 0 : null === (o = V[0]) || void 0 === o ? void 0 : o.slug)
                        }), (null === (c = V[0]) || void 0 === c ? void 0 : null === (h = c.product) || void 0 === h ? void 0 : null === (g = h.categories_service) || void 0 === g ? void 0 : g.button_link) === "packaging" && (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("title", {
                                children: (null == V ? void 0 : null === (m = V[0]) || void 0 === m ? void 0 : m.meta_title) ? null == V ? void 0 : null === (x = V[0]) || void 0 === x ? void 0 : x.meta_title : "".concat(null == V ? void 0 : null === (j = V[0]) || void 0 === j ? void 0 : j.title, " & ").concat(null == V ? void 0 : null === (_ = V[0]) || void 0 === _ ? void 0 : _.title, "  Packaging | Biotech Packages")
                            }), (0, l.jsx)("meta", {
                                property: "og:title",
                                content: (null == V ? void 0 : null === (b = V[0]) || void 0 === b ? void 0 : b.meta_title) ? null == V ? void 0 : null === (f = V[0]) || void 0 === f ? void 0 : f.meta_title : "".concat(null == V ? void 0 : null === (y = V[0]) || void 0 === y ? void 0 : y.title, " & ").concat(null == V ? void 0 : null === (w = V[0]) || void 0 === w ? void 0 : w.title, "  Packaging | Biotech Packages")
                            }), (0, l.jsx)("meta", {
                                property: "og:description",
                                content: (null == V ? void 0 : null === (k = V[0]) || void 0 === k ? void 0 : k.meta_description) ? null == V ? void 0 : null === (N = V[0]) || void 0 === N ? void 0 : N.meta_description : "Print & design your own ".concat(null == V ? void 0 : null === (P = V[0]) || void 0 === P ? void 0 : P.title, " with logo from Biotech Packages. Custom ").concat(null == V ? void 0 : null === (C = V[0]) || void 0 === C ? void 0 : C.title, " packaging with quality material at ✌ cheap prices ➤ 100% recycled!")
                            }), (0, l.jsx)("meta", {
                                name: "description",
                                content: (null == V ? void 0 : null === (F = V[0]) || void 0 === F ? void 0 : F.meta_description) ? null == V ? void 0 : null === (T = V[0]) || void 0 === T ? void 0 : T.meta_description : "Print & design your own ".concat(null == V ? void 0 : null === (W = V[0]) || void 0 === W ? void 0 : W.title, " with logo from Biotech Packages. Custom ").concat(null == V ? void 0 : null === (B = V[0]) || void 0 === B ? void 0 : B.title, " packaging with quality material at ✌ cheap prices ➤ 100% recycled!")
                            })]
                        }), (null === (S = V[0]) || void 0 === S ? void 0 : null === (Z = S.product) || void 0 === Z ? void 0 : null === (E = Z.categories_service) || void 0 === E ? void 0 : E.button_link) === "stickerandlabels" && (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("title", {
                                children: (null == V ? void 0 : null === (D = V[0]) || void 0 === D ? void 0 : D.meta_title) ? null == V ? void 0 : null === (O = V[0]) || void 0 === O ? void 0 : O.meta_title : "".concat(null == V ? void 0 : null === (z = V[0]) || void 0 === z ? void 0 : z.title, " & Custom  ").concat(null == V ? void 0 : null === (L = V[0]) || void 0 === L ? void 0 : L.title, "  Wholesale")
                            }), (0, l.jsx)("meta", {
                                property: "og:title",
                                content: (null == V ? void 0 : null === (Y = V[0]) || void 0 === Y ? void 0 : Y.meta_title) ? null == V ? void 0 : null === (q = V[0]) || void 0 === q ? void 0 : q.meta_title : "".concat(null == V ? void 0 : null === (A = V[0]) || void 0 === A ? void 0 : A.title, " & Custom  ").concat(null == V ? void 0 : null === (G = V[0]) || void 0 === G ? void 0 : G.title, "  Wholesale")
                            }), (0, l.jsx)("meta", {
                                property: "og:description",
                                content: (null == V ? void 0 : null === (R = V[0]) || void 0 === R ? void 0 : R.meta_description) ? null == V ? void 0 : null === (X = V[0]) || void 0 === X ? void 0 : X.meta_description : "Customized ".concat(null == V ? void 0 : null === (U = V[0]) || void 0 === U ? void 0 : U.title, " with a variety of designs & shapes. Printed ").concat(null == V ? void 0 : null === (H = V[0]) || void 0 === H ? void 0 : H.title, " wholesale from Biotech Packages professional at cheap prices!\n\n          ")
                            }), (0, l.jsx)("meta", {
                                name: "description",
                                content: (null == V ? void 0 : null === (I = V[0]) || void 0 === I ? void 0 : I.meta_description) ? null == V ? void 0 : null === (J = V[0]) || void 0 === J ? void 0 : J.meta_description : "Customized ".concat(null == V ? void 0 : null === (K = V[0]) || void 0 === K ? void 0 : K.title, " with a variety of designs & shapes. Printed ").concat(null == V ? void 0 : null === (M = V[0]) || void 0 === M ? void 0 : M.title, " wholesale from Biotech Packages professional at cheap prices!")
                            })]
                        }), (0, l.jsx)("link", {
                            rel: "icon",
                            href: "/images/bioblacklogo.png"
                        }), (0, l.jsx)("script", {
                            async: !0,
                            src: "https://www.googletagmanager.com/gtag/js?id=G-94FWCDD0CW"
                        }), (0, l.jsx)("script", {
                            children: "\n    window.dataLayer = window.dataLayer || [];  function gtag(){dataLayer.push(arguments);}  gtag('js', new Date());  gtag('config', 'G-94FWCDD0CW');\n  "
                        })]
                    }), (0, l.jsx)("main", {
                        children: $ ? (0, l.jsx)(p.default, {}) : (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)(d.Z, {}), (0, l.jsx)(t.Z, {}), (0, l.jsx)(a.Z, {}), (0, l.jsx)(s.Z, {}), (0, l.jsx)(n.Z, {})]
                        })
                    })]
                })
            };
            var g = !0;
            e.default = h
        }
    },
    function(i) {
        i.O(0, [776, 3081, 395, 7356, 5955, 9590, 2199, 9774, 2888, 179], function() {
            return i(i.s = 6629)
        }), _N_E = i.O()
    }
]);